// Se define el PATCH de la API
const API_URL = 'https://rickandmortyapi.com/api/character';

// Ejecuto el llamado de la función que desencadena el fetch
const data = await fetchCharacter(API_URL);
buildCharacter(data.results)

axiosCharacter(API_URL)

/**
 * fetchCharacter
 * 
 * Función que se encarga de consumir la API con fetch
 * @param {string} API_URL 
 */
async function fetchCharacter(API_URL) {
    try {
        const response = await fetch(API_URL);
        if(!response.ok) {
            throw new Error("Error al consumir la API");
        }
        return await response.json()
    } catch (error) {
        console.log(error + "hola")
    }
        
}

async function axiosCharacter(API_URL) {
    try {
        const response = await axios(API_URL);
        console.log(response);
        return response;
    } catch (error) {
        console.log("Hay un error en la API")
    }
}

/**
 * 
 * @param {object} characters 
 */
function buildCharacter(characters) {
    const build = document.getElementById("character-render")
    characters.forEach(element => {
        let divContainer = document.createElement("div")
        
        let name = document.createElement("h2")
        name.textContent = element.name
        
        let characterPic = document.createElement("img")
        characterPic.setAttribute("src", element.image)
        
        divContainer.append(name, characterPic)
        build.append(divContainer)

    });
    
}