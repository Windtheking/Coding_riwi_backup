
//not a valid js code, just exploring functions

Swal.fire("SweetAlert2 is working!");
// let first = document.getElementById("submit_button");

// document.addEventListener

// function dontreload(){
//     let name =  document.getElementById("").value;
//     let email =  document.getElementById("").value;
// }

/*event.preventDefault()  --> para evitar que cuando ocurra algo  se recargue la pagina*/ 