The Initial program is needed to be used step by step, for the main option of the CRUD method (create, read, update, delete) you need to enter the selection you chose, to register a new book you need to first have in mind that you wont be able to insert values in a empty or none existent key you need to create the new key first to insert values inside of it not to insert it instantly, for the consult you need to insert the name of what you want to see and the press enter to go back for the updates you need to first choose the value to update and then insert what is required for it and lastly for deletion you only need to insert values needed do have in mind you cannot erase none existent values

for the costumer wants a book option you only need to insert the values ask of you from the console and the program will obtain based on how many books you want of the same how much you have to pay or if you have discount or not, do have in mind that it is needed this option for you to be able to succesfully proceed with the overall repot

the overall report will have to, show the 3 best sellers and overall sales but also the gross and net income, have in mind that if you dont have any previouys costumers the incomce will apear negative always

Project made with

- Python
- Visual estudio
